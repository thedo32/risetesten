<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="table-responsive">
                <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary my-3">
                Add Post
                </a>
                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show my-1" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show my-1" role="alert">
                    <?php echo e(session('error')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <?php endif; ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Title</th>
                            <th scope="col">Desc</th>
                            <th scope="col">Category</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e(++$key); ?></th>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e(Str::limit( strip_tags( $item->desc ), 60 )); ?></td>
                                <td><?php echo e($item->category->name); ?></td>
                                <td>
                                    <a href="<?php echo e(route('posts.edit', $item->id)); ?>" class="btn btn-success btn-sm">Edit</a>
                                    <form method="POST" action="<?php echo e(route('posts.destroy', [$item->id])); ?>" class="d-inline" onsubmit="return confirm('Move post to trash ?')">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="submit" value="Delete" class="btn btn-danger btn-sm">
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_website\resources\views/posts/index.blade.php ENDPATH**/ ?>