<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Primary Meta Tags -->
        <title><?php echo e($post->title); ?></title>
        <meta name="title" content="<?php echo e($post->title); ?>">
        <meta name="description" content="<?php echo e($post->meta_desc); ?>">
        <meta name="keywords" content="<?php echo e($post->keywords); ?>">
        <!-- Open Graph / Facebook -->
        <meta property="og:type" content="article">
        <meta property="og:url" content="<?php echo e(URL::current()); ?>">
        <meta property="og:title" content="<?php echo e($post->title); ?>">
        <meta property="og:description" content="<?php echo e($post->meta_desc); ?>">
        <meta property="og:image" content="<?php echo e(asset('storage/'.$post->cover)); ?>">
        <!-- Twitter -->
        <meta property="twitter:card" content="summary_large_image">
        <meta property="twitter:url" content="<?php echo e(URL::current()); ?>">
        <meta property="twitter:title" content="<?php echo e($post->title); ?>">
        <meta property="twitter:description" content="<?php echo e($post->meta_desc); ?>">
        <meta property="twitter:image" content="<?php echo e(asset('storage/'.$post->cover)); ?>">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
<style>
/* center the image */
        .imgcenter {
        display: block;
        margin-left: auto;
        margin-right: auto;
        width:50%;
    }
        

/* go top button */
#myBtn {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  font-size: 18px;
  border: none;
  outline: none;
  background-color: red;
  color: white;
  cursor: pointer;
  padding: 15px;
  border-radius: 4px;
}

#myBtn:hover {
  background-color: #555;
}
</style>
</head>

    </head>
    <body>
<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
        <div class="container">
        <a class="navbar-brand" alt="logo" href="<?php echo e(url('/')); ?>"> <img src="/mntw/storage/app/public/images/logo/mentawaves_logo_web.png">
                      </a>
        </div>
</nav>
 
<button onclick="topFunction()" id="myBtn" title="Go to top">Ûp</button>

<script>
// Get the button
let mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
        
        
        <div class="container my-5">
            <div class="row">
                <div class="card">
                    <img src="<?php echo e(asset('storage/'.$post->cover)); ?>" alt="" class="imgcenter" "img-responsive" >
                    <div class="card-body">
                        <h1 class="card-title"><?php echo e($post->title); ?></h1>
                        <div class="d-flex my-2">
                            <small class="text-muted">by <?php echo e($post->user->name); ?> ・ <?php echo e(Carbon\Carbon::parse($post->created_at)->isoFormat('D MMMM Y')); ?></small>
                        </div>
                        <p><?php echo $post->desc; ?></p>
                        <div class="card-footer bg-transparent d-flex mx-auto">
                            <a href="<?php echo e(route('category',$post->category->slug)); ?>" class="text-dark"><?php echo e($post->category->name); ?></a>
                            <div class="d-flex ml-auto">
                                <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('tag', $item->slug)); ?>" class="badge badge-secondary mr-1"><?php echo e($item->name); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\mntw\resources\views/show.blade.php ENDPATH**/ ?>