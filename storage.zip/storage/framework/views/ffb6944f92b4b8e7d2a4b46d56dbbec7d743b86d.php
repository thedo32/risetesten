<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
        <?php if(isset($category)): ?>

        <title><?php echo e($category->name); ?></title>
                 <meta name="title" content="<?php echo e($category->name); ?>">
        <meta name="description" content="<?php echo e($category->meta_desc); ?>">
        <meta name="keywords" content="<?php echo e($category->keywords); ?>">
        <?php endif; ?>
        <?php if(isset($tag)): ?>
        <title><?php echo e($tag->name); ?></title>
        <meta name="title" content="<?php echo e($tag->name); ?>">
        <meta name="description" content="<?php echo e($tag->meta_desc); ?>">
        <meta name="keywords" content="<?php echo e($tag->keywords); ?>">
        <?php endif; ?>
        <?php if(!isset($tag) && !isset($category)): ?>
        <title><?php echo e(config('app.name', 'MNTW.XYZTEM.XYZ')); ?></title>
        <?php endif; ?>
        
         <!---Link FontAwesome Social Media Icon and others--->
        <link rel="stylesheet" href="../resources/css/all.css">
        <link rel="stylesheet" href="../resources/css/tailwind.css">
        

<!-- slider dari BarajaCoding -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {box-sizing: border-box}
body {font-family: Verdana, sans-serif; margin:0}
.mySlides {display: none;}
img {vertical-align: middle;}

.slideshow-container {
  max-width: 800px;
  position: relative;
  margin-top:90px;
  margin-bottom:10px;
  margin-right: auto;
  margin-left: auto;
 }

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/4 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 30s;
  animation-name: fade;
  animation-duration: 30s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes  fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media  only screen and (max-width: 500px) {
  .prev, .next,.text {font-size: 10px}
  .slideshow-container{margin-top:230px};
}

/*end of barajacoding */

/*background with image */
.fix-navbar {
    position: fixed;
    overflow: hidden;
    background-image: url('/storage/app/public/images/bg/background.png');
    top: 0; /* Position the navbar at the top of the page */
    width: 100%; /* Full width */
    z-index:99;
}
.bg-body {
    background-image: url('/storage/app/public/images/bg/bodybg.jpg');
    background-attachment: fixed;
}


</style>


    </head>
    <body class="bg-body">
    <nav class="navbar navbar-expand-md navbar-light fix-navbar shadow-sm">
        <div class="container">
                <a class="navbar-brand" alt="logo" href="<?php echo e(url('/')); ?>"> <img src="/storage/app/public/images/logo/logo.gif" width = "138" height = "86">
                </a>
                    <div class= "table"> 
		                <a class="social-media-icon" href="https://www.facebook.com/jeffri.kun.argon" target="_blank"><span class="fab fa-15x fa-facebook"></span>
		                </a>
		                <a class="social-media-icon" href="https://www.instagram.com/thedo32" target="_blank"><span class="fab fa-15x fa-instagram"></span>
		                </a>
		                <a class="social-media-icon" href="https://www.linkedin.com/in/jeffriargon" target="_blank"><span class="fab fa-15x fa-linkedin"></span>
		                </a>
		                <a class="social-media-icon" href="https://www.github.com/thedo32" target="_blank"><span class="fab fa-15x fa-github"></span>
		                </a>
		                <a class="social-media-icon" href="https://www.twitter.com/jeffri_tsg" target="_blank"><span class="fab fa-15x fa-x-twitter"></span>
		                </a>
	    	        </div>
                    
					  
				<button class=" table navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>
     
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="text-center navbar-nav mr-auto">
						<li class="nav-item <?php echo e(request()->is('tags') ? 'active' : ''); ?>">
                            <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>                     
						<li class="nav-item <?php echo e(request()->is('tags') ? 'active' : ''); ?>">
                            <a class="nav-link" href="<?php echo e(route('tag', 'article')); ?>">Articles</a>
                        </li>
                        <li class="nav-item <?php echo e(request()->is('categories') ? 'active' : ''); ?>">
                            <a class="nav-link" href="<?php echo e(route('tag', 'news')); ?>">News</a>
                        </li>
                        <li class="nav-item <?php echo e(request()->is('categories') ? 'active' : ''); ?>">
                            <a class="nav-link" href="<?php echo e(route('tag', 'about')); ?>">About</a>    
                        </li>
            </div>    
       </div>
       
       
    </nav>

    <div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 4</div>
  <img src="/storage/app/public/images/slider/1.png" style="width:100%">
 <!-- < <div class="text">Caption One</div> --> 
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 4</div>
  <img src="/storage/app/public/images/slider/2.png" style="width:100%">
  <!-- <div class="text">Caption Two</div> -->
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 4</div>
  <img src="/storage/app/public/images/slider/3.png" style="width:100%">
  <!-- <div class="text">Caption Three</div> -->
</div>

<div class="mySlides fade">
  <div class="numbertext">4 / 4</div>
 <img src="/storage/app/public/images/slider/4.png" style="width:100%">
  <!-- <div class="text">Caption Fours</div> -->
</div>


<script>
var slideIndex = 1;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace("active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  setTimeout(showSlides, 10000); // Change image every 4 seconds
}



</script>

        <div class="container mt-5">
            <?php if(isset($category)): ?>
            <h2 class="text-center my-3">Blog Category: <?php echo e($category->name); ?></h2>
            <?php endif; ?>
            <?php if(isset($tag)): ?>
            <h2 class="text-center my-3">Blog Tag: <?php echo e($tag->name); ?></h2>
            
            <?php endif; ?>
            <?php if(!isset($tag) && !isset($category)): ?>
         
            <?php endif; ?>
            <h2 class= "text-center my-3 animate-text bg-gradient-to-r from-teal-500 via-purple-500 to-orange-500 bg-clip-text text-transparent text-8x11 font-black ">another ratty in the cage, another embryo in transparent egg - jeffri argon</h2> 
            <div class="row">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-4 mt-3">
                    <div class="card">
                        <div class="container-post">
                            <a href="<?php echo e(route('show', $item->slug)); ?>">
                                <img src="<?php echo e(asset('storage/'.$item->cover)); ?>" class="card-img-top image-post" alt="...">
                            </a>
                            <div class="middle-post">
                                <a href="<?php echo e(route('show', $item->slug)); ?>">
                                    <div class="text-post"><?php echo e($item->title); ?></div>
                                 </a> 
                            </div>
                        </div>
                        <div class="card">
                            <a href="<?php echo e(route('show', $item->slug)); ?>" class="text-dark">
                                <h5 class="text-titles"><?php echo e($item->title); ?></h5>
                            </a>
                        </div>
                        <div class="card-footer">
                            <div class="d-flex mx-auto">
                                <?php $__currentLoopData = $item->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tags): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('tag', $tags->slug)); ?>" class="badge badge-secondary mr-1"><?php echo e($tags->name); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <small class="text-5x8 text-muted ml-auto"><?php echo e(Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?></small>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
    </body>
</html>
<?php /**PATH /home/xyzs5697/public_html/resources/views/all.blade.php ENDPATH**/ ?>