<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Primary Meta Tags -->
        <title><?php echo e($post->title); ?></title>
        <meta name="title" content="<?php echo e($post->title); ?>">
        <meta name="description" content="<?php echo e($post->meta_desc); ?>">
        <meta name="keywords" content="<?php echo e($post->keywords); ?>">
        <!-- Open Graph / Facebook -->
        <meta property="og:type" content="article">
        <meta property="og:url" content="<?php echo e(URL::current()); ?>">
        <meta property="og:title" content="<?php echo e($post->title); ?>">
        <meta property="og:description" content="<?php echo e($post->meta_desc); ?>">
        <meta property="og:image" content="<?php echo e(asset('storage/'.$post->cover)); ?>">
        <!-- Twitter -->
        <meta property="twitter:card" content="summary_large_image">
        <meta property="twitter:url" content="<?php echo e(URL::current()); ?>">
        <meta property="twitter:title" content="<?php echo e($post->title); ?>">
        <meta property="twitter:description" content="<?php echo e($post->meta_desc); ?>">
        <meta property="twitter:image" content="<?php echo e(asset('storage/'.$post->cover)); ?>">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
        
          <!---Link FontAwesome Social Media Icon and others--->
        <link rel="stylesheet" href="../resources/css/all.css">
        <link rel="stylesheet" href="../resources/css/tailwind.css">
        
<style>
/* center the image */
        .imgcenter {
        display: block;
        margin-top:55px;
        margin-bottom:10px;
        margin-left: auto;
        margin-right: auto;
        width:35%;
    }
    
/*end of center the image */
        

/* go top button */
#myBtn {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 98;
  font-size: 15px;
  border: none;
  outline: none;
  background-color: red;
  color: white;
  cursor: pointer;
  padding: 10px;
  border-radius: 4px;
  opacity:0.5;
}

#myBtn:hover {
  background-color: #555;
}
/*end of go top button */

/* On smaller screens, decrease text size */
@media  only screen and (max-width: 500px) {
  .prev, .next,.text {font-size: 10px}
  .imgcenter{margin-top:180px};
}


/*background with image */
.fix-navbar {
    position: fixed;
    overflow: hidden;
    background-image: url('/storage/app/public/images/bg/background.png');
    top: 0; /* Position the navbar at the top of the page */
    width: 100%; /* Full width */
    z-index:99;
}
.bg-body {
    background-image: url('/storage/app/public/images/bg/bodybg.jpg');
    background-attachment: fixed;
}

</style>
</head>

    </head>
    <body class="bg-body">
<nav class="navbar navbar-expand-md navbar-light fix-navbar shadow-sm">
        <div class="container">
                <a class="navbar-brand" alt="logo" href="<?php echo e(url('/')); ?>"> <img src="/storage/app/public/images/logo/logo.gif" width = "138" height = "86">
                </a>
                    <div class= "table"> 
		                <a class="social-media-icon" href="https://www.facebook.com/jeffri.kun.argon" target="_blank"><span class="fab fa-15x   fa-facebook"></span>
		                </a>
		                <a class="social-media-icon" href="https://www.instagram.com/thedo32" target="_blank"><span class="fab fa-15x   fa-instagram"></span>
		                </a>
		                <a class="social-media-icon" href="https://www.linkedin.com/in/jeffriargon" target="_blank"><span class="fab fa-15x   fa-linkedin"></span>
		                </a>
		                <a class="social-media-icon" href="https://www.github.com/thedo32" target="_blank"><span class="fab fa-15x   fa-github"></span>
		                </a>
		                <a class="social-media-icon" href="https://www.twitter.com/jeffri_tsg" target="_blank"><span class="fab fa-15x   fa-x-twitter"></span>
		                </a>
	    	        </div>
                    
					  
				<button class=" table navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>
     
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="text-center navbar-nav mr-auto">
							<li class="nav-item <?php echo e(request()->is('tags') ? 'active' : ''); ?>">
                            <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>                     
						<li class="nav-item <?php echo e(request()->is('tags') ? 'active' : ''); ?>">
                            <a class="nav-link" href="<?php echo e(route('category', 'kedokteran')); ?>">Kedokteran</a>
                        </li>
                        <li class="nav-item <?php echo e(request()->is('tags') ? 'active' : ''); ?>">
                            <a class="nav-link" href="<?php echo e(route('category', 'nutrisi')); ?>">Nutrisi</a>
                        </li>
                        <li class="nav-item <?php echo e(request()->is('tags') ? 'active' : ''); ?>">
                            <a class="nav-link" href="<?php echo e(route('category', 'kebidanan')); ?>">Kebidanan</a>
                        </li>
                        <li class="nav-item <?php echo e(request()->is('categories') ? 'active' : ''); ?>">
                            <a class="nav-link" href="<?php echo e(route('tag', 'about')); ?>">About</a>    
                        </li>
            </div> 
					  
        </div>
</nav>
 
<button onclick="topFunction()" id="myBtn" title="Go to top">Ûp</button>

<script>
// Get the button
let mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
}
</script>
        
        
        <div class="container-show">
            <div class="row">
                <div class="card">
                    <img src="<?php echo e(asset('storage/'.$post->cover)); ?>" alt="" class="imgcenter" "img-responsive" >
                    <div class="card-body">
                        <h1 class="card-title"><?php echo e($post->title); ?></h1>
                        <div class="d-flex my-2">
                            <small class="text-muted">by <?php echo e($post->user->name); ?> ・ <?php echo e(Carbon\Carbon::parse($post->created_at)->isoFormat('D MMMM Y')); ?></small>
                        </div>
                        <p><?php echo $post->desc; ?></p>
                        <div class="card-footer bg-transparent d-flex mx-auto">Pengarang: <?php echo $post->author; ?></div>
                        <div class="card-footer bg-transparent d-flex mx-auto">ISBN: <?php echo $post->isbn; ?></div>
                        <div class="card-footer bg-transparent d-flex mx-auto">Penerbit: <?php echo $post->publisher; ?></div>
                        <div class="card-footer bg-transparent d-flex mx-auto">Tahun Terbit: <?php echo $post->pub_date; ?></div>
                        <div class="card-footer bg-transparent d-flex mx-auto">Harga Rp: <?php echo number_format($post->harga_est,0,",","."); ?></div>
                        <div class="card-footer bg-transparent d-flex mx-auto">
                            <a href="<?php echo e(route('category',$post->category->slug)); ?>" class="text-dark"><?php echo e($post->category->name); ?></a>
                            <div class="d-flex ml-auto">
                                <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('tag', $item->slug)); ?>" class="badge badge-secondary mr-1"><?php echo e($item->name); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
    </body>
    <footer>
            <div class="shadowfooter">
                 &copy; <script>document.write(new Date().getFullYear())</script> Pilar Telaten
            </div>
    </footer>
</html>
<?php /**PATH /home/xyzs5697/public_html/bukupilar/resources/views/show.blade.php ENDPATH**/ ?>