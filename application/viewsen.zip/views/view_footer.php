   <br>
   <div class="shadowfooter">
		<table class=footer-table>
			<td><a href="<?php echo base_url('home');?>"> &copy;<script>document.write(new Date().getFullYear())</script></a></td>
			<td><a href="https://maps.app.goo.gl/8eJkzCjkXjDBQoY38" target="_blank" class=h13>Kupi Batigo Menara: <br>  Jl. KH. Ahmad Dahlan No.19, Alai Parak Kopi, Kec. Padang Utara, Kota Padang, Sumbar</a></td>
			<td><a href="https://maps.app.goo.gl/PixFebUQzGGMkroU6" target="_blank" class=h13>Kupi Batigo Teluk Buo: <br> Teluk Kabung Tengah, Kec. Bungus Teluk Kabung, Kota Padang, Sumbar</a></td>
			<td><a href="https://maps.app.goo.gl/NU48SwiZ72wsQ4wy9" target="_blank" class=h13>Rumah Puti Painan: <br>  Jl. Pagaruyung I No.No.3, Painan, Kec. Iv Jurai, Kab. Pesisir Selatan, Sumbar</a></td>
		</table>
	</div>
</body>
</html>
