<!DOCTYPE html>
<html>
        <head>
				<!-- Place the first <script> tag in your HTML's <head> -->
				<script type="text/javascript" src="<?php echo base_url(); ?>../extension/js/app.js"></script>
				<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
				<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
				<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>



				<!-- css script to load -->
				 <!--  <link rel="stylesheet" type="text/css" href=" php echo base_url(); ?>../public/assets/css/tailwind.css"> -->
				
				 <!-- font awesome -->
				<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
              	
				<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>../extension/css/app.css">


				  <!-- Bootstrap CSS -->
				<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">

				<title>Kupi Batigo</title>	
