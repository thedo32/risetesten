   <p>
   <div class="shadowfooter">
         &copy; <script>document.write(new Date().getFullYear())</script> Kupi Batigo
    </div>
</body>
</html>
