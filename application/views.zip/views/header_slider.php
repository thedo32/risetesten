<!-- slider dari BarajaCoding -->

<div class="slideshow-container">	
	<div class="mySlides fade">
		<a alt="Menara" href="<?php echo base_url('');?>"><img src="<?php echo base_url ("/storage/app/public/images/slider/1.png");?>" style="width:80%"></a>
		<!-- < <div class="text">Caption One</div> --> 
	</div>

	<div class="mySlides fade">
		<a alt="Menara" href="<?php echo base_url('taluak');?>"><img src="<?php echo base_url ("/storage/app/public/images/slider/2.png");?>" style="width:80%"></a>
		<!-- <div class="text">Caption Two</div> -->
	</div>

	<div class="mySlides fade">
		<a alt="Menara" href="<?php echo base_url('taluak');?>"><img src="<?php echo base_url ("/storage/app/public/images/slider/3.png");?>" style="width:80%"></a>
		<!-- <div class="text">Caption Three</div> -->
	</div>
	
	<div class="mySlides fade">
		<a alt="Menara" href="<?php echo base_url('painan');?>"><img src="<?php echo base_url ("/storage/app/public/images/slider/4.png");?>" style="width:80%"></a>
		<!-- <div class="text">Caption Four</div> -->
	</div>
</div>

<script>
	var slideIndex = 0;
	showSlides();
</script>

<!-- end of slider dari BarajaCoding -->
