<?php
defined('BASEPATH') or exit('No direct script access allowed');

$config['twilio_sid'] = 'AC21fafee48b33145e512fe560eccbd6b3';
$config['twilio_token'] = '66adfb138c29eac34c1aaf06579b14a1';
$config['twilio_phone_number'] = '+628994659530';
